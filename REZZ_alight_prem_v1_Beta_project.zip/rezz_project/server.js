// REZZ backend: magic-link request + verification only.
// Never expose provider tokens to the browser. Configure a trusted auth provider.
const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json({ limit: '12kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const API_URL = process.env.AUTH_API_URL;
const PORT = Number(process.env.PORT || 3000);

async function providerPost(action, data) {
  if (!API_URL) throw new Error('AUTH_API_URL belum dikonfigurasi.');
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, ...data })
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const err = new Error(body.message || `Provider error (${response.status})`);
    err.status = response.status;
    throw err;
  }
  return body;
}

app.post('/api/send-magiclink', async (req, res) => {
  const email = String(req.body?.email || '').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ success: false, message: 'Format email tidak valid.' });
  }
  try {
    const result = await providerPost('send-magiclink', { email });
    if (!result.success) return res.status(400).json({ success: false, message: result.message || 'Provider menolak permintaan.' });
    res.json({ success: true, message: 'Permintaan magic link diterima.' });
  } catch (e) {
    res.status(e.status || 502).json({ success: false, message: e.message || 'Provider tidak tersedia.' });
  }
});

app.post('/api/verify-magiclink', async (req, res) => {
  const email = String(req.body?.email || '').trim();
  const rawLink = String(req.body?.rawLink || '').trim();
  if (!email || !rawLink || rawLink.length > 5000) {
    return res.status(400).json({ success: false, message: 'Email atau magic link tidak valid.' });
  }
  try {
    const result = await providerPost('verify-account', { email, rawLink });
    // Deliberately do not return idToken/profile/token to the browser.
    if (!result.success) return res.status(400).json({ success: false, message: result.message || 'Verifikasi gagal.' });
    res.json({ success: true, message: 'Identitas berhasil diverifikasi.' });
  } catch (e) {
    res.status(e.status || 502).json({ success: false, message: e.message || 'Verifikasi tidak tersedia.' });
  }
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`REZZ berjalan di http://localhost:${PORT}`));
