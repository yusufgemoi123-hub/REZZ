# REZZ alight prem v1 (Beta)

## Menjalankan
1. Install Node.js 18+.
2. Jalankan `npm install`.
3. Salin `.env.example` menjadi `.env`.
4. Isi `AUTH_API_URL` hanya dengan endpoint autentikasi resmi/tepercaya yang kamu kelola atau memang berwenang kamu gunakan.
5. Jalankan `npm start`, lalu buka `http://localhost:3000`.

## Keamanan
- Frontend tidak memanggil provider secara langsung.
- `idToken` tidak dikirim kembali ke browser.
- Project ini hanya meminta Magic Link dan memverifikasi identitas.
- Tidak ada aksi `apply-premium` atau pembelian otomatis. Lanjutkan pembelian melalui checkout resmi yang disediakan vendor.
- Jangan menaruh API key, secret, atau token akun di HTML.
- Endpoint pihak ketiga yang tidak dikenal dapat menerima email dan tautan login sensitif. Jangan gunakan sebelum kamu memastikan pemilik dan izinnya.
